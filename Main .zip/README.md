# Common Kid
**Power is a choice.** An iPad-friendly political history and diplomacy browser game prototype.

## Current MVP
- Three branching political decision scenes
- Public trust, influence, and stability scores
- Consequence log and replay
- Local browser save/load
- Responsive layout designed for phones and iPads
- No dependencies or build step

## Run
Open `index.html` in a modern browser.

## GitHub Pages deployment
1. Upload `index.html` and this README to the `main` branch.
2. Open repository **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Choose branch `main` and folder `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site.

## Roadmap
1. Add historically sourced chapters with citations.
2. Introduce factions, diplomacy, resource trade-offs, and campaign outcomes.
3. Improve accessibility, touch controls, and save-version handling.
4. Test on iPad Safari and additional mobile browsers.
5. Add an optional backend only if multiplayer or cloud saves become necessary.

## Accuracy and privacy
The opening campaign is fictional. Historical chapters should distinguish documented facts from interpretation and include sources. Saves currently stay in browser local storage and are not sent to a server.
